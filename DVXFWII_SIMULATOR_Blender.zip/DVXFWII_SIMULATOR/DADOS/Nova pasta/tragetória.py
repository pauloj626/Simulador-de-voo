import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

def reduz_pontos(l):
    n = 25
    return [l[i*n] for i in range(int(len(l)/n)+1)]

a = np.loadtxt('pos_x_y_z_6.txt')
b = np.loadtxt('pos_x_y_z_v6.txt')
c = np.loadtxt('pos_x_y_z_vc4.txt')

T = [a[:,0], b[:,0], c[:,0]]
x = [a[:,1], b[:,1], c[:,1]]
y = [a[:,2], b[:,2], c[:,2]]
z = [a[:,3], b[:,3], c[:,3]]

'''
fig = plt.figure()
ax = fig.gca(projection='3d')

ax.plot(x[0], y[0], z[0]-1000, color = 'b')
ax.plot(x[1], y[1], z[1]-1000, color = 'r')
ax.plot(x[2], y[2], z[2]-1000, color = 'k')
'''

plt.plot(x[0], y[0], color = 'b')
plt.plot(reduz_pontos(x[0]), reduz_pontos(y[0]), color = 'b', marker = '^', label = r'$+0(m/s)$')

x[1] = x[1][:len(x[1])-150]
y[1] = y[1][:len(y[1])-150]
plt.plot(x[1], y[1], color = 'r')
plt.plot(reduz_pontos(x[1]), reduz_pontos(y[1]), color = 'r', marker = 'o', label = r'$+4(m/s)$')

plt.plot(x[2], y[2], color = 'y')
plt.plot(reduz_pontos(x[2]), reduz_pontos(y[2]), color = 'y', marker = '*', label = r'$-4(m/s)$')

plt.xlabel('Tragetória em x(m)')
plt.ylabel('Tragetória em y(m)')
plt.title(r'Curva em voo com/sem Vento de Través')
plt.legend()
plt.show()
