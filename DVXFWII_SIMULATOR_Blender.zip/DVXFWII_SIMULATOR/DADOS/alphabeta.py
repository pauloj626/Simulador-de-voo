import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

a = np.loadtxt('pos_x_y_z.txt')
b = np.loadtxt('angs_ar_a_b.txt')

T = a[:,0]
x = a[:,1]
y = a[:,2]
z = a[:,3]

af = b[:,0]
bt = b[:,1]
'''
fig = plt.figure()
ax = fig.gca(projection='3d')

ax.plot(x, y, z, color = 'b')
'''
plt.plot(T, 180*bt/np.pi, color = 'b')

plt.show()

