import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import numpy as np

a = np.loadtxt('pos_x_y_z.txt')
b = np.loadtxt('forces_D_L_Y.txt')
c = np.loadtxt('controle_in.txt')
#print(b)
T = a[:,0]
x = a[:,1]
y = a[:,2]
z = a[:,3]
print(len(b[:,1]), len(T))
L = b[:,1]
D = b[:,0]
Y = b[:,2]

P = 180*c[:,2]/np.pi

ac = np.sqrt(L**2 + D**2 + Y**2)
'''
fig = plt.figure()
ax = fig.gca(projection='3d')
ax.set_aspect('equal')
ax.plot(x, y, z, color = 'b')
#ax.axis([-60, 200, -60, 200])
plt.show()
'''
plt.figure(1)
if len(T) > len(P):
    plt.plot(T[len(T) - len(P):], P, color = 'b')
else:
    plt.plot(T, P[len(P) - len(T):], color = 'b')
#plt.plot(x, y)

plt.show()

